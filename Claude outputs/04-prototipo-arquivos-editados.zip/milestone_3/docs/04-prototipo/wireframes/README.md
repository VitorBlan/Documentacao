# Wireframes

Fábrica de Software I · Protótipo do sistema · Milestones 1 a 3

Esta pasta reúne as telas do Bancada exportadas em SVG da página "[03 · Protótipo](https://www.figma.com/design/EHj0Js5KtOJ88TRQd5fTJI/Gest%C3%A3o-de-Oficina-Mec%C3%A2nica?node-id=3-36)" do Figma. As telas estão em [`Meuprojetooficina/`](<Meuprojetooficina/0 - Índice.md>), em uma pasta por área do menu lateral, e o [índice das telas](<Meuprojetooficina/0 - Índice.md>) relaciona cada arquivo ao nome do quadro original no Figma.

| Pasta | Área | Perfil | Telas | Histórias | IFML |
|---|---|---|---|---|---|
| [1 - Login](<Meuprojetooficina/1 - Login/>) | Login | Todos | 1 | US-001 | IFML-01 |
| [2 - Painel](<Meuprojetooficina/2 - Painel/>) | Painel | Secretária | 1 | US-002 (parcial) | IFML-01 |
| [3 - Orçamento](<Meuprojetooficina/3 - Orçamento/>) | Orçamentos | Secretária | 22 | US-016, US-017, US-018, US-026 | IFML-05 |
| [4 - Ordens de serviço](<Meuprojetooficina/4 - Ordens de serviço/>) | OS | Secretária | 9 | US-009, US-012, US-015, US-027, US-028 | IFML-04 |
| [5 - Clientes](<Meuprojetooficina/5 - Clientes/>) | Clientes | Secretária | 9 | US-003, US-004, US-005, US-010, US-013 | IFML-02 |
| [6 - Veículos](<Meuprojetooficina/6 - Veículos/>) | Carros e histórico do veículo | Secretária | 11 | US-006, US-007, US-011, US-014, US-029, US-030 | IFML-03, IFML-06 |
| [7 - Peças e estoque](<Meuprojetooficina/7 - Peças e estoque/>) | Peças e Estoque e Distribuidora | Estoquista | 31 | US-019 a US-024; distribuidoras sem história | IFML-07 |
| [8 - Agenda dos boxes](<Meuprojetooficina/8 - Agenda dos boxes/>) | Agenda dos Box | Secretária | 5 | #42 | Sem modelo |
| [9 - Relatórios](<Meuprojetooficina/9 - Relatórios/>) | Relatórios | Gerente | 1 | Sem história (RF-07) | Sem modelo |
| [Rótulos](<Meuprojetooficina/Rótulos/>) | Títulos de seção do canvas | — | 26 | — | — |

Total: 90 telas. Na pasta 7, as telas 7.27 a 7.31 são a versão anterior das telas de peças, mantida como registro do redesenho.

**Convenção.** Arquivo `N.NN - Tela - estado (US-nnn).svg`: `N` é a pasta da área, `NN` é a ordem da tela no fluxo, e a história aparece entre parênteses quando está registrada no GitLab. Quadros de desktop, com o menu lateral agrupado em Atendimento, Cadastros e Gestão.

## Veja também

- [Índice do protótipo e revisão de usabilidade](../README.md)
- [Site map](../site-map.md)
- [IFML](../ifml/README.md)
- [Histórias de usuário](../../03-requisitos/historias-de-usuario.md)
